package anything;

public class Sai {

	public static void main(String[] args) {
		sagar ss = new sagar();
		int e = ss.m1();

		System.out.println(e);
	}
}
