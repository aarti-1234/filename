package anything;

public class sagar {

	int m1() {

		Emp e1 = new Emp();
		e1.setId(1);
		e1.setName("amit");
		e1.setSalary(12345);

		int salary = e1.getSalary();
		return salary;
	}

}
